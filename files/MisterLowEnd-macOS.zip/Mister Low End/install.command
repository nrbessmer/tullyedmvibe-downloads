#!/bin/bash
# Tully EDM Vibe plugin installer for macOS
# (c)(p) 2026 Tully EDM Vibe  -  info@tullyedmvibe.com
#
# Put this file in the same folder as the plugin bundles you downloaded
# (for example "Mister Low End.component" and "Mister Low End.vst3").
#
#   Install:    double-click install.command
#               (or in Terminal:  bash ~/Downloads/<folder>/install.command)
#   Uninstall:  bash install.command --uninstall
#
# Installs for the current user only (no admin password needed):
#   AU   -> ~/Library/Audio/Plug-Ins/Components
#   VST3 -> ~/Library/Audio/Plug-Ins/VST3

set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
AU_DIR="$HOME/Library/Audio/Plug-Ins/Components"
VST3_DIR="$HOME/Library/Audio/Plug-Ins/VST3"
MODE="install"
[ "${1:-}" = "--uninstall" ] && MODE="uninstall"

echo "Tully EDM Vibe plugin installer"
echo "Folder: $HERE"
echo

shopt -s nullglob
BUNDLES=("$HERE"/*.component "$HERE"/*.vst3)
if [ ${#BUNDLES[@]} -eq 0 ]; then
  echo "No .component or .vst3 files found next to this script."
  echo "Unzip the download, keep install.command in the same folder as the plugins, and run it again."
  read -n 1 -s -r -p "Press any key to close."; echo
  exit 1
fi

# Logic and other hosts must be closed or they keep the old plugin loaded.
for app in "Logic Pro" "Logic Pro X" "Ableton Live" "MainStage" "GarageBand"; do
  if pgrep -x "$app" >/dev/null 2>&1; then
    echo "Please quit $app first, then run this installer again."
    read -n 1 -s -r -p "Press any key to close."; echo
    exit 1
  fi
done

mkdir -p "$AU_DIR" "$VST3_DIR"
FAILED=0

for src in "${BUNDLES[@]}"; do
  name="$(basename "$src")"
  case "$name" in
    *.component) dest="$AU_DIR/$name"  ; kind="AU"   ;;
    *.vst3)      dest="$VST3_DIR/$name"; kind="VST3" ;;
  esac

  if [ "$MODE" = "uninstall" ]; then
    if [ -e "$dest" ]; then
      rm -rf "$dest" && echo "Removed  $kind  $name"
    else
      echo "Not installed  $kind  $name"
    fi
    continue
  fi

  rm -rf "$dest"
  if ! cp -R "$src" "$dest"; then
    echo "FAILED to copy $name"; FAILED=1; continue
  fi
  # Files downloaded from the internet are tagged "quarantined" by macOS,
  # which stops DAWs from loading them. Clear that tag on the installed copy.
  xattr -dr com.apple.quarantine "$dest" 2>/dev/null
  # Re-apply a local signature so Apple Silicon Macs accept the binary.
  codesign --force --deep --sign - "$dest" >/dev/null 2>&1
  echo "Installed $kind  $name"
done

# Make macOS rescan Audio Units so Logic sees the change.
killall -9 AudioComponentRegistrar >/dev/null 2>&1
rm -rf "$HOME/Library/Caches/AudioUnitCache" >/dev/null 2>&1

echo
if [ "$MODE" = "uninstall" ]; then
  echo "Done. The plugins have been removed."
elif [ $FAILED -eq 0 ]; then
  echo "Done. Open your DAW. In Logic Pro the plugins are listed under"
  echo "Tully EDM Vibe (Audio Units). Logic re-scans new plugins on launch."
  echo "If a plugin shows as 'failed validation', open Logic's Plug-in Manager,"
  echo "select it and click 'Reset & Rescan Selection'."
else
  echo "Some files could not be installed. Email info@tullyedmvibe.com"
  echo "with a screenshot of this window."
fi
echo
read -n 1 -s -r -p "Press any key to close."; echo
